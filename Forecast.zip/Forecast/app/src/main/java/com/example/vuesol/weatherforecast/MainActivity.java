package com.example.vuesol.weatherforecast;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import javax.net.ssl.HttpsURLConnection;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.et1) EditText et1;
    @BindView(R.id.b1) Button b1;

    String zipCode = "";
    String apiKey = "f79194a6d91e3c80d08030ea261743f5";
    Context ctx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ctx = this;
        setContentView(R.layout.activity_main);

        ButterKnife.bind(this);

        InputFilter[] filterArray = new InputFilter[1];
        filterArray[0] = new InputFilter.LengthFilter(6);
        et1.setFilters(filterArray);
        et1.setInputType(InputType.TYPE_CLASS_NUMBER);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                zipCode = et1.getText().toString();
                if (zipCode.length() != 5)
                    Toast.makeText(ctx, "Please enter a valid zip code", Toast.LENGTH_LONG).show();
                else
                    new CallAPI().execute(getAPIURL(zipCode));
            }
        });
    }

    public String getAPIURL(String zcode) {
        return "http://api.openweathermap.org/data/2.5/weather?zip=" + zcode + ",us&APPID=" + apiKey + "&units=Imperial";
    }

    public static ProgressDialog createProgressDialog(Context context) {
        ProgressDialog dialog = new ProgressDialog(context);
        try {
            dialog.show();
        } catch (WindowManager.BadTokenException e) {
            e.printStackTrace();
        }
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.progress_dialog);
        return dialog;
    }

    public static String getSourceCode(String requestURL) {
        String response = "";
        try {
            URL url = new URL(requestURL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            int responseCode = conn.getResponseCode();
            if (responseCode == HttpsURLConnection.HTTP_OK) {
                String line;
                BufferedReader br = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), "UTF-8"));
                while ((line = br.readLine()) != null) {
                    response += line;
                }
            } else {
                response = "";
            }
        } catch (IOException e) {
            e.printStackTrace();
            return response;
        }
        return response;
    }

    public class CallAPI extends AsyncTask<String, Integer, String> {
        ProgressDialog pd;

        @Override
        public void onPreExecute() {
            super.onPreExecute();
            pd = createProgressDialog(ctx);
            pd.show();
        }

        @Override
        public String doInBackground(String... params) {
            Log.d("sdcsdvcdf", params[0] + "z");
            String res = getSourceCode(params[0]);
            return res;
        }

        @Override
        public void onPostExecute(String result) {
            super.onPostExecute(result);
            if (pd.isShowing())
                pd.dismiss();
            if (result.length() == 0)
                Toast.makeText(ctx, "Please check zip code.", Toast.LENGTH_LONG).show();
            else try {
                JSONObject jsonObject = new JSONObject(result);
                JSONArray eSubObj1 = jsonObject.getJSONArray("weather");

                Log.v("here", eSubObj1.toString());

                Double temperature = Double.parseDouble(jsonObject.getJSONObject("main").optString("temp"));
                Long rise = Long.parseLong(jsonObject.getJSONObject("sys").optString("sunrise"));

                Intent i = new Intent(ctx, Details.class);
                i.putExtra("weather_main", eSubObj1.getJSONObject(0).optString("main") + "");
                i.putExtra("weather_description", eSubObj1.getJSONObject(0).optString("description") + "");
                i.putExtra("main_temp",getFormattedTemp(temperature)) ;
                i.putExtra("main_pressure", jsonObject.getJSONObject("main").optString("pressure") + " hpa");
                i.putExtra("main_humidity", jsonObject.getJSONObject("main").optString("humidity") + "%");
                i.putExtra("wind_speed", jsonObject.getJSONObject("wind").optString("speed") + " m/s");
                i.putExtra("sys_clouds", jsonObject.getJSONObject("clouds").optString("all") + "");
                i.putExtra("sys_sunrise", getFormattedTime(rise));
                i.putExtra("name", jsonObject.optString("name") + "");
                startActivity(i);
            } catch (JSONException jse) {
                jse.printStackTrace();
                Toast.makeText(ctx, "Please enter valid zip code.", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(ctx, "Something went wrong. Please check your internet or try later.", Toast.LENGTH_LONG).show();
            }
        }

        public String getFormattedTime(Long time){
            SimpleDateFormat formatter = new SimpleDateFormat("h:mm a");
            Date dateTime = new Date(time * 1000);
            String timeString = formatter.format(dateTime);

            return timeString;
        }

        public String getFormattedTemp(Double temp){

            int iTemp = (int)Math.round(temp);
            String sTemp =  Integer.toString(iTemp);

            return sTemp;
        }
    }
}
