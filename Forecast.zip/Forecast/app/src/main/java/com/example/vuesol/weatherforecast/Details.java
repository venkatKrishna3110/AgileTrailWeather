package com.example.vuesol.weatherforecast;


import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;

public class Details extends AppCompatActivity {

    @BindView(R.id.weather_heading) TextView weatherHeading;
    @BindView(R.id.weather_sub_heading) TextView weatherSubHeading;
    @BindView(R.id.faren) TextView faren;
    @BindView(R.id.main_pressure) TextView mainPressure;
    @BindView(R.id.main_humidity) TextView mainHumidity;
    @BindView(R.id.wind_speed) TextView windSpeed;
    @BindView(R.id.sys_clouds) TextView sysClouds;
    @BindView(R.id.sys_sunrise) TextView sysSunrise;
    @BindView(R.id.name) TextView name;

    Context ctx;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ctx = this;
        setContentView(R.layout.activity_details);

        ButterKnife.bind(this);

        weatherHeading.setText(getIntent().getStringExtra("weather_main"));
        weatherSubHeading.setText(getIntent().getStringExtra("weather_description"));
        faren.setText(getIntent().getStringExtra("main_temp"));
        mainPressure.setText(getIntent().getStringExtra("main_pressure")+ " ");
        mainHumidity.setText(getIntent().getStringExtra("main_humidity")+ " ");
        windSpeed.setText(getIntent().getStringExtra("wind_speed")+ " ");
        sysClouds.setText(getIntent().getStringExtra("sys_clouds"));
        sysSunrise.setText(getIntent().getStringExtra("sys_sunrise"));
        name.setText("Measured: " + getIntent().getStringExtra("name"));
    }
}
